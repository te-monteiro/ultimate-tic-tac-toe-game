
// Store references to relevant elements
const cellElements = document.querySelectorAll('.mini-board .cell');
const startGameMessageText = document.getElementById('startGame');
const winningMessageTextElement = document.querySelector('[data-winning-message-text]');
const restartButton = document.getElementById('restartButton');
const playerXWinsElement = document.getElementById('playerXWins');
const playerOWinsElement = document.getElementById('playerOWins');
const winningMessageElement = document.getElementById('winningMessage');

const gameModeSelection = document.getElementById('gameModeSelection');
const startGameButton = document.getElementById('startGameButton');
const userButton = document.getElementById('mode-user');
const computerButton = document.getElementById('mode-computer');

const socket = new WebSocket('ws://localhost:3000');

// Initialize game variables
let player2 ;
let currentPlayer;  
let playerXWin = 0;
let playerCircleWin = 0;
let activeMiniBoard = 0;

// Define constants for player symbols
const X_PLAYER = 'x';
const CIRCLE_PLAYER = 'circle';

const WINNING_COMBINATIONS = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [6, 4, 2]
];

socket.addEventListener('open', (event) => {
    console.log('WebSocket connection opened');
});

startGameButton.addEventListener('click', showGameModes);
restartButton.addEventListener('click', showGameModes);

function showGameModes() {
    startGameButton.style.display = 'none';
    startGameMessageText.style.display = 'none';
    gameModeSelection.classList.add('show');
    winningMessageElement.classList.remove('show');
    // Initialize the ultimate tic-tac-toe board
    logicalBoard = [
    // Subgrid 1
    [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ],
    // Subgrid 2
    [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ],
    // Subgrid 3
    [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ],
    // Subgrid 4
    [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ],
    // Subgrid 5
    [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ],
    // Subgrid 6
    [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ],
    // Subgrid 7
    [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ],
    // Subgrid 8
    [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ],
    // Subgrid 9
    [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ]
];

}

userButton.addEventListener('click', () => startGame('user'));
computerButton.addEventListener('click', () => startGame('computer'));

function startGame(selectedMode) {
    player2 = false;
    gameModeSelection.classList.remove('show');
    currentPlayer = X_PLAYER;

    // Handle the selected mode and start the game accordingly
    if (selectedMode === 'user') {
        // Start the game in user vs. user mode
        startUserVsUserGame();
    } else if (selectedMode === 'computer') {
        // Start the game in user vs. computer mode
        startUserVsComputerGame();
    }
}

function startUserVsUserGame() {
    cellElements.forEach(cell => {
        cell.classList.remove(X_PLAYER);
        cell.classList.remove(CIRCLE_PLAYER);
        cell.removeEventListener('click', handleClick);
        cell.addEventListener('click', handleClick, { once: true });
    });
    showBoardHover(activeMiniBoard);
}

function startUserVsComputerGame() {
    cellElements.forEach(cell => {
        cell.classList.remove(X_PLAYER);
        cell.classList.remove(CIRCLE_PLAYER);
        cell.removeEventListener('click', handleClick_computer);
        cell.addEventListener('click', handleClick_computer, { once: true });
    });
    showBoardHover(activeMiniBoard);
}


function handleClick(e) {
    const cell = e.target;
    const miniBoardId = cell.closest('.mini-board').id;
    const miniBoardNumber = parseInt(miniBoardId.replace('mini-board-', ''), 10);
    if (activeMiniBoard === 0 || activeMiniBoard === miniBoardNumber || !checkSubgridWinner(miniBoardNumber)) {
        
        currentPlayer = player2 ? CIRCLE_PLAYER : X_PLAYER;
        placeMark(cell, currentPlayer);
    
        const opponentPlayer = player2 ? X_PLAYER : CIRCLE_PLAYER;
        
        // Check for win
        if (checkWinInMiniBoard(currentPlayer, miniBoardNumber)) {
            console.log("entrei no win mini board ")
            activeMiniBoard = miniBoardNumber;
            endSubgridGame(false)

        } else if(checkWinInMiniBoard(opponentPlayer, miniBoardNumber)){
            // Allow the current player to choose any open subgrid
            activeMiniBoard = 0;

        }else {
            if (checkWin(currentPlayer)) {
                if (currentPlayer === X_PLAYER) {
                    playerXWin++;
                    sendGameResults(playerXWin, miniBoardNumber);
                } else if (currentPlayer === CIRCLE_PLAYER) {
                    playerCircleWin++;
                    sendGameResults(playerCircleWin, miniBoardNumber);
                }
                updateCurrentPlayerDisplay();
                updateWinCounts();
                endGame(false);
            } else if (isGameDraw()) {
                console.log("entrei no draw ")
                // check for draw
                endGame(true);
            } else {
                switchPlayer();
                //activeMiniBoard = miniBoardNumber;
                console.log("activeMiniBoard ", activeMiniBoard , "miniBoardNumber ", miniBoardNumber )
                showBoardHover();
            }
            updateActiveMiniBoard(cell);
        }
    }
}


function handleClick_computer(e){
    const cell = e.target;
    const miniBoardId = cell.closest('.mini-board').id;
    const miniBoardNumber = parseInt(miniBoardId.replace('mini-board-', ''), 10);
    if (activeMiniBoard === 0 || activeMiniBoard === miniBoardNumber || !checkSubgridWinner(miniBoardNumber)) {
        //updateActiveMiniBoard(cell);
        currentPlayer = player2 ? CIRCLE_PLAYER : X_PLAYER;
        // placeMark
        placeMark(cell, currentPlayer);
        
        // Update the logical board based on the HTML board
        updateLogicalBoard();

        const opponentPlayer = player2 ? X_PLAYER : CIRCLE_PLAYER;
        if (checkWinInMiniBoard(currentPlayer, miniBoardNumber)) {
            console.log("entrei no win mini board ")
            activeMiniBoard = miniBoardNumber;
            endSubgridGame(false)

        } else if(checkWinInMiniBoard(opponentPlayer, miniBoardNumber)){
            // Allow the current player to choose any open subgrid
            activeMiniBoard = 0;

        }else {
            if (checkWin(currentPlayer)) {
                if (currentPlayer === X_PLAYER) {
                    playerXWin++;
                    sendGameResults(playerXWin, miniBoardNumber);
                } else if (currentPlayer === CIRCLE_PLAYER) {
                    playerCircleWin++;
                    sendGameResults(playerCircleWin, miniBoardNumber);
                }
                updateCurrentPlayerDisplay();
                updateWinCounts();
                endGame(false);
            } else if (isGameDraw()) {
                console.log("entrei no draw ")
                // check for draw
                endGame(true);
            } else {
                switchPlayer();
                const aiMove = aiMakeMove(currentPlayer);
                let move = cellElements[aiMove];
                placeMark(move, currentPlayer);

                updateLogicalBoard();

                const opponentPlayer = player2 ? X_PLAYER : CIRCLE_PLAYER;
        
                // Check for win
                if (checkWinInMiniBoard(currentPlayer, miniBoardNumber)) {
                    console.log("entrei no win mini board ")
                    activeMiniBoard = miniBoardNumber;
                    endSubgridGame(false)

                } else if(checkWinInMiniBoard(opponentPlayer, miniBoardNumber)){
                    // Allow the current player to choose any open subgrid
                    activeMiniBoard = 0;

                }else {
                    // Check for win or draw after the AI move
                    if (checkWin(currentPlayer)) {
                        if (currentPlayer === X_PLAYER) {
                            playerXWin++;
                            sendGameResults(playerXWin, miniBoardNumber);
                        } else if (currentPlayer === CIRCLE_PLAYER) {
                            playerCircleWin++;
                            sendGameResults(playerCircleWin, miniBoardNumber);
                        }
                        updateCurrentPlayerDisplay();
                        updateWinCounts();
                        endGame(false);
                    } else if (isGameDraw()) {
                        console.log("entrei no draw ")
                        // check for draw
                        endGame(true);
                    } else {
                        // Switch turn back to the user
                        switchPlayer();
                        showBoardHover();
                    }
                    updateActiveMiniBoard(cell);
                }
            }
        }
    }
}


updateWinCounts();

function updateActiveMiniBoard(cell) {
    console.log(cell)
    const miniBoardId = cell.closest('.mini-board').id;
    activeMiniBoard = parseInt(miniBoardId.replace('mini-board-', ''), 10);
    const cellIndex = getCellIndex(cell);
    activeMiniBoard = cellIndex + 1;
    // Convert the updated value back to the mini-board ID format
    const nextMiniBoardId = `mini-board-${activeMiniBoard}`;
    const nextMiniBoardElement = document.getElementById(nextMiniBoardId);
    
    // Ensure the nextMiniBoardElement exists before updating activeMiniBoard
    if (nextMiniBoardElement) {
        activeMiniBoard = nextMiniBoardId;
    }
}


function checkWin(currentPlayer) {
    // Check for overall game win
    return WINNING_COMBINATIONS.some(combination => {
        const [a, b, c] = combination;
        return (
            // Check if all three mini-boards in this combination are won by the same player
            checkWinInMiniBoard(currentPlayer, a) && 
            checkWinInMiniBoard(currentPlayer, b) && 
            checkWinInMiniBoard(currentPlayer, c)
        );
    });
}

function checkWinInMiniBoard(player, miniBoardElements) {
    const miniBoardCells = document.querySelectorAll(`#mini-board-${miniBoardElements} .cell`);
    
    const itIsDraw = [...miniBoardCells].every(cell => {
        return cell.classList.contains(X_PLAYER) || cell.classList.contains(CIRCLE_PLAYER);
    });

    if (itIsDraw) {
        return true;
    }

    return WINNING_COMBINATIONS.some(combination => {
        return combination.every(index => {
            return miniBoardCells[index].classList.contains(player);
        });
    });
}


function endGame(draw) {
    if (draw) {
        winningMessageTextElement.innerText = 'It\'s a draw!';
    } else {
        winningMessageTextElement.innerText = `${player2 ? 'Player O' : 'Player X'} Wins!`;
    }
    winningMessageElement.classList.add('show');

    // Check for the overall game end condition
    if (playerXWin >= 3 || playerCircleWin >= 3 || isBoardFull()) {
        // Display the overall game result
        showGameResult();
        restartGame();
    }
}
function endSubgridGame(draw) {
    const subgridWinnerElement = document.getElementById('SubgridWinner');
    const winnerSymbol = player2 ? CIRCLE_PLAYER : X_PLAYER;
    
    if (draw) {
        subgridWinnerElement.innerText = 'It\'s a draw!';
    } else {
        subgridWinnerElement.innerText = `${player2 ? 'Player O' : 'Player X'} Wins Subgrid!`;
        subgridWinnerElement.classList.add('show');
        displaySubgridWinner(winnerSymbol)
        showBoardHover(activeMiniBoard)
    }
}

function displaySubgridWinner(winnerSymbol) {
    console.log("winner Symbol ", winnerSymbol)
    const subgridWinnerElement = document.getElementById('SubgridWinner');

    if (subgridWinnerElement) {
        const symbol = winnerSymbol === X_PLAYER ? 'X' : 'O';
        subgridWinnerElement.textContent = `Subgrid Winner: ${symbol}`;
        subgridWinnerElement.classList.add('show');
    } else {
        console.error("Element with ID 'SubgridWinner' not found");
    }
}

function updateCurrentPlayerDisplay() {
    const currentPlayerElement = document.getElementById('currentPlayer');
    if (currentPlayerElement) {
        currentPlayerElement.textContent = 'Current Player:' + currentPlayer;
    } else {
        console.error("Element with ID 'currentPlayer' not found");
    }
}


function isDraw(miniBoardNumber) {
    const miniBoardCells = document.querySelectorAll(`#mini-board-${miniBoardNumber} .cell`);

    // Log the classes of each cell in the mini-board
    [...miniBoardCells].forEach(cell => {
        console.log(cell.classList);
    });

    [...miniBoardCells].every(cell => {
        return cell.classList.contains(X_PLAYER) || cell.classList.contains(CIRCLE_PLAYER);
    });

}
function isGameDraw() {
    // Iterate over each mini-board
    for (let miniBoardNumber = 1; miniBoardNumber <= 9; miniBoardNumber++) {
        if (!isDraw(miniBoardNumber)) {
            // If any mini-board is not a draw, return false
            return false;
        }
    }
    // If all mini-boards are draws, return true
    return true;
}


function checkSubgridWinner(miniBoardNumber) {
    const subgridCells = document.querySelectorAll(`#mini-board-${miniBoardNumber} .cell`);

    // Extract the classes of the cells in the subgrid
    const cellClasses = Array.from(subgridCells).map(cell => cell.classList.contains(X_PLAYER) ? X_PLAYER : (cell.classList.contains(CIRCLE_PLAYER) ? CIRCLE_PLAYER : ''));

    // Check for a win in the subgrid (horizontally, vertically, or diagonally)
    return (
        // Check horizontal win
        checkLineWin(cellClasses, 0, 1, 2) ||
        checkLineWin(cellClasses, 3, 4, 5) ||
        checkLineWin(cellClasses, 6, 7, 8) ||
        // Check vertical win
        checkLineWin(cellClasses, 0, 3, 6) ||
        checkLineWin(cellClasses, 1, 4, 7) ||
        checkLineWin(cellClasses, 2, 5, 8) ||
        // Check diagonal win
        checkLineWin(cellClasses, 0, 4, 8) ||
        checkLineWin(cellClasses, 2, 4, 6)
    );
}
/* // Check Vertical win
function checkVerticalWin(cell1, cell2, cell3, currentPlayer) {
    return (cell1 === currentPlayer && cell2 === currentPlayer && cell3 === currentPlayer);
}
// Check Horizontal win
function checkLineWin(cell1, cell2, cell3, currentPlayer) {
    return (cell1 === currentPlayer && cell2 === currentPlayer && cell3 === currentPlayer);
}
// Check diagonal win
if (checkDiagonalWin(ultimateTicTacToeBoard[0][0], ultimateTicTacToeBoard[1][1], ultimateTicTacToeBoard[2][2], currentPlayer)) {
    return true;
} */

function isBoardFull() {
    return [...cellElements].every(cell => {
        return cell.classList.contains(X_PLAYER) || cell.classList.contains(CIRCLE_PLAYER);
    });
}

function getCellIndex(cell) {
    return Array.from(cell.parentNode.children).indexOf(cell);
}


function aiMakeMove(currentPlayer) {
    return minimax(logicalBoard, 0, currentPlayer === CIRCLE_PLAYER).move;
} 

function checkWin_imaginaryWin(new_board, currentPlayer) {
    return WINNING_COMBINATIONS.some(combination => {
        return combination.every(index => {
            return new_board[index] === currentPlayer;
        });
    });
    }

function isImaginaryDraw(new_board){
    return new_board.every(cell => {
        return cell === X_PLAYER || cell === CIRCLE_PLAYER;
    });
}
function minimax(new_board, depth, isMaximizing) {
    var bestMove;
    var bestScore;

    if (checkWin_imaginaryWin(new_board, CIRCLE_PLAYER)) {
        return { score: 1 }; // CIRCLE_player wins
    } else if (checkWin_imaginaryWin(new_board, X_PLAYER)) {
        return { score: -1 }; // X_player wins
    } else if (isImaginaryDraw(new_board)) {
        return { score: 0 }; // It's a draw
    }

    if (isMaximizing) {
        bestScore = -Infinity;
        for (let i = 0; i < new_board.length; i++) {
            if (new_board[i] === '') {
                new_board[i] = CIRCLE_PLAYER;
                let score = minimax(new_board, depth + 1, false).score;
                new_board[i] = '';

                if (score > bestScore) {
                    bestScore = score;
                    bestMove = i;
                }
            }
        }
    } else {
        bestScore = Infinity;
        for (let i = 0; i < new_board.length; i++) {
            if (new_board[i] === '') {
                new_board[i] = X_PLAYER;
                let score = minimax(new_board, depth + 1, true).score;
                new_board[i] = '';

                if (score < bestScore) {
                    bestScore = score;
                    bestMove = i;
                }
            }
        }
    }

    return { score: bestScore, move: bestMove };
}
function updateLogicalBoard() {
    for (let miniBoardIndex = 0; miniBoardIndex < 9; miniBoardIndex++) {
        const miniBoardCells = document.querySelectorAll(`#mini-board-${miniBoardIndex + 1} .cell`);

        // Iterate over each cell in the mini-board
        miniBoardCells.forEach((cell, index) => {
            const row = Math.floor(index / 3); // Calculate the row within the mini-board
            const col = index % 3; // Calculate the column within the mini-board

            // Calculate the row and column within the logical board
            const logicalRow = Math.floor(miniBoardIndex / 3) * 3 + row;
            const logicalCol = (miniBoardIndex % 3) * 3 + col;

            // Update the logical board based on the player in the cell
            if (cell.classList.contains(X_PLAYER)) {
                logicalBoard[logicalRow][logicalCol] = X_PLAYER;
            } else if (cell.classList.contains(CIRCLE_PLAYER)) {
                logicalBoard[logicalRow][logicalCol] = CIRCLE_PLAYER;
            }
        });
    }
 /*    logicalBoard = cellElements.map((cell) => {
        if (cell.classList.contains(X_PLAYER)) {
            return X_PLAYER;
        } else if (cell.classList.contains(CIRCLE_PLAYER)) {
            return CIRCLE_PLAYER;
        }
    }); */
}


// Function to place a mark in the cell
function placeMark(cell, currentPlayer) {
    cell.classList.add(currentPlayer);
    updateActiveMiniBoard(cell); // Update the active mini-board

}


function showBoardHover() {
   
    // Clear the blocked-cell class from all cells
    document.querySelectorAll('.cell').forEach(cell => {
        cell.classList.remove('blocked-cell');
    });

        // Add the blocked-cell class to cells in other mini boards
    const activeMiniBoardSelector = "[id=" + activeMiniBoard + "]";
    document.querySelectorAll('.mini-board:not(' + activeMiniBoardSelector + ') .cell').forEach(cell => {
        cell.classList.add('blocked-cell');
    });


  //  }
    

    // Clear the previous winner symbol when showing the next board
    const subgridWinnerElement = document.getElementById('SubgridWinner');
    if (subgridWinnerElement) {
        subgridWinnerElement.innerHTML = '';
        subgridWinnerElement.classList.remove('show');
    }
    /* for (let i = 0; i < 9; i++) {
        const boardElement = document.getElementById(`tic-tac-toe-board-${i}`);
        if (boardElement) {
            if (i + 1 === miniBoardNumber) {
                boardElement.classList.add('next-mini-board');
            } else {
                boardElement.classList.remove('next-mini-board');
            }
        }
    }
    // Add the blocked-cell class to cells in other mini boards
    document.querySelectorAll('.mini-board:not(#mini-board-' + miniBoardNumber + ') .cell').forEach(cell => {
        cell.classList.add('blocked-cell');
    });
  
    // Clear the previous winner symbol when showing the next board
    const subgridWinnerElement = document.getElementById('SubgridWinner');
    if (subgridWinnerElement) {
        subgridWinnerElement.innerHTML = '';
        subgridWinnerElement.classList.remove('show');
    } */
}

//not complete
function showGameResult() {
    if (playerXWin >= 3) {
        console.log(playerXWin)
    } else if (playerCircleWin >= 3) {
        // Player Circle wins the game
        // Handle the game end result as needed
        console.log(playerCircleWin)
    } else {
        // It's a tie (entire board is filled)
        console.log("DRAW BIG GAME")

    }
}

// Function to update win counts on the display
function updateWinCounts() {
    playerXWinsElement.textContent = playerXWin;
    playerOWinsElement.textContent = playerCircleWin;
}

// Function to switch to the other player
function switchPlayer() {
    player2 = !player2;
}

// Function to display the winning message
function showWinningMessage(message) {
    winningMessageTextElement.textContent = message;
}

function sendGameResults(result, miniBoardNumber){
    socket.send(JSON.stringify({type: 'result', data: {result, miniBoardNumber} }));
}

function restartGame() {
    winningMessageElement.classList.remove('show');
    logicalBoard = Array(81).fill('');
    resetGame();
}
