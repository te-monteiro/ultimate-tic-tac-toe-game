

// Store references to relevant elements
const cellElements = document.querySelectorAll('.mini-board .cell');
const startGameMessageText = document.getElementById('startGame');
const winningMessageTextElement = document.querySelector('[data-winning-message-text]');
const restartButton = document.getElementById('restartButton');
const playerXWinsElement = document.getElementById('playerXWins');
const playerOWinsElement = document.getElementById('playerOWins');
const winningMessageElement = document.getElementById('winningMessage');

const gameModeSelection = document.getElementById('gameModeSelection');
const startGameButton = document.getElementById('startGameButton');
const userButton = document.getElementById('mode-user');
const computerButton = document.getElementById('mode-computer');

const socket = new WebSocket('ws://localhost:3000');

socket.addEventListener('open', (event) => {
    console.log('WebSocket connection opened');
});


// Initialize game variables
let player2 ;
let playerXWin = 0;
let playerCircleWin = 0;
let currentPlayer;

// Define constants for player symbols
const X_PLAYER = 'x';
const CIRCLE_PLAYER = 'circle';

let activeMiniBoard = 0;


const WINNING_COMBINATIONS = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [6, 4, 2]
];


startGameButton.addEventListener('click', showGameModes);
restartButton.addEventListener('click', showGameModes);

updateWinCounts();
function showGameModes() {
    startGameButton.style.display = 'none';
    startGameMessageText.style.display = 'none';
    gameModeSelection.classList.add('show');
    winningMessageElement.classList.remove('show');
    logicalBoard = ['', '', '', '', '', '', '', '', ''];
}

userButton.addEventListener('click', () => startGame('user'));
computerButton.addEventListener('click', () => startGame('computer'));

function restartGame() {
    winningMessageElement.classList.remove('show');
    logicalBoard = Array(81).fill('');
    resetGame();
}
function startGame(selectedMode) {
    player2 = false;
    gameModeSelection.classList.remove('show');
    currentPlayer = X_PLAYER;

    // Handle the selected mode and start the game accordingly
    if (selectedMode === 'user') {
        // Start the game in user vs. user mode
        startUserVsUserGame();
    } else if (selectedMode === 'computer') {
        // Start the game in user vs. computer mode
        startUserVsComputerGame();
    }
}

function startUserVsUserGame() {
    cellElements.forEach(cell => {
        cell.classList.remove(X_PLAYER);
        cell.classList.remove(CIRCLE_PLAYER);
        cell.removeEventListener('click', handleClick);
        cell.addEventListener('click', handleClick, { once: true });
    });
    showBoardHover(activeMiniBoard);
}

function startUserVsComputerGame() {
    cellElements.forEach(cell => {
        cell.classList.remove(X_PLAYER);
        cell.classList.remove(CIRCLE_PLAYER);
        cell.removeEventListener('click', handleClick_computer);
        cell.addEventListener('click', handleClick_computer, { once: true });
    });
    showBoardHover(activeMiniBoard);
}


function handleClick(e) {
    const cell = e.target;
    console.log(cell)
    const miniBoardId = cell.closest('.mini-board').id;
    const miniBoardNumber = parseInt(miniBoardId.replace('mini-board-', ''), 10);
    console.log( "miniboard number ", miniBoardNumber , " activeMiniBoard ", activeMiniBoard)
    if (activeMiniBoard === 0 || activeMiniBoard === miniBoardNumber) {

        currentPlayer = player2 ? CIRCLE_PLAYER : X_PLAYER;
        placeMark(cell, currentPlayer);
    
        // Check for win
        if (checkWin(currentPlayer, miniBoardNumber)) {
            if (currentPlayer === X_PLAYER) {
                playerXWin++;
                sendGameResults(playerXWin, miniBoardNumber);
            } else {
                playerCircleWin++;
                sendGameResults(playerCircleWin, miniBoardNumber);
            }
            updateCurrentPlayerDisplay();
            updateWinCounts();
            endGame(false);
        } else if (isDraw()) {
            // check for draw
            endGame(true);
        } else {
            switchPlayer();
            activeMiniBoard = miniBoardNumber;
            showBoardHover(activeMiniBoard);
        }
    }
}

function handleClick_computer(e){
    const cell = e.target;
    const miniBoardId = cell.closest('.mini-board').id;
    const miniBoardNumber = parseInt(miniBoardId.replace('mini-board-', ''), 10);
    if (activeMiniBoard === 0 || activeMiniBoard === getCellIndex(e.target)) {

        currentPlayer = player2 ? CIRCLE_PLAYER : X_PLAYER;
        // placeMark
        placeMark(cell, currentPlayer);
        
        // Update the logical board based on the HTML board
        updateLogicalBoard();
        
        // Check for win
        if (checkWin(currentPlayer)) {
            if (currentPlayer === X_PLAYER) {
                playerXWin++;
            } else {
                playerCircleWin++;
            }
            sendGameResults(result, tabNumber);
            updateWinCounts();
            endGame(false);
        } else if (isDraw()) {
            // check for draw
            endGame(true);
        } else {
            switchPlayer();
            // Switch turn to the AI
            currentPlayer = player2 ? CIRCLE_PLAYER : X_PLAYER;
            
            // Call aiMakeMove with the updated logical board
            const aiMove = aiMakeMove(currentPlayer);
            let move = cellElements[aiMove];
            placeMark(move, currentPlayer);
    
            // Update the HTML board
            updateLogicalBoard();    
            // Check for win or draw after the AI move
            if (checkWin(CIRCLE_PLAYER)) {
                playerCircleWin++;
                updateWinCounts();
                endGame(false);
            } else if (isDraw()) {
                endGame(true);
            } else {
                // Switch turn back to the user
                switchPlayer();
                activeMiniBoard = miniBoardNumber;
                showBoardHover(activeMiniBoard);
            }
        }
    }
}

function getCellIndex(cell) {
    return Array.from(cell.parentNode.children).indexOf(cell);
}
function aiMakeMove(currentPlayer) {
    return minimax(logicalBoard, 0, currentPlayer === CIRCLE_PLAYER).move;
}
function checkWin(currentPlayer) {
    return WINNING_COMBINATIONS.some(combination => {
      return combination.every(index => {
        return cellElements[index].classList.contains(currentPlayer)
      })
    })
  }
function checkWin_imaginaryWin(new_board, currentPlayer) {
    return WINNING_COMBINATIONS.some(combination => {
        return combination.every(index => {
            return new_board[index] === currentPlayer;
        });
    });
    }

function isImaginaryDraw(new_board){
    return new_board.every(cell => {
        return cell === X_PLAYER || cell === CIRCLE_PLAYER;
    });
}
function minimax(new_board, depth, isMaximizing) {
    var bestMove;
    var bestScore;

    if (checkWin_imaginaryWin(new_board, CIRCLE_PLAYER)) {
        return { score: 1 }; // CIRCLE_player wins
    } else if (checkWin_imaginaryWin(new_board, X_PLAYER)) {
        return { score: -1 }; // X_player wins
    } else if (isImaginaryDraw(new_board)) {
        return { score: 0 }; // It's a draw
    }

    if (isMaximizing) {
        bestScore = -Infinity;
        for (let i = 0; i < new_board.length; i++) {
            if (new_board[i] === '') {
                new_board[i] = CIRCLE_PLAYER;
                let score = minimax(new_board, depth + 1, false).score;
                new_board[i] = '';

                if (score > bestScore) {
                    bestScore = score;
                    bestMove = i;
                }
            }
        }
    } else {
        bestScore = Infinity;
        for (let i = 0; i < new_board.length; i++) {
            if (new_board[i] === '') {
                new_board[i] = X_PLAYER;
                let score = minimax(new_board, depth + 1, true).score;
                new_board[i] = '';

                if (score < bestScore) {
                    bestScore = score;
                    bestMove = i;
                }
            }
        }
    }

    return { score: bestScore, move: bestMove };
}
function updateLogicalBoard() {
    logicalBoard = cellElements.map((cell) => {
        if (cell.classList.contains(X_PLAYER)) {
            return X_PLAYER;
        } else if (cell.classList.contains(CIRCLE_PLAYER)) {
            return CIRCLE_PLAYER;
        } else {
            return '';
        }
    });
}
/* function updateLogicalBoard() {
    // Clear the logical board
    for (let i = 0; i < logicalBoard.length; i++) {
        logicalBoard[i] = '';
    }

    // Update the logical board based on the HTML board
    for (let i = 0; i < cellElements.length; i++) {
        if (cellElements[i].classList.contains(X_PLAYER)) {
            logicalBoard[i] = X_PLAYER;
        } else if (cellElements[i].classList.contains(CIRCLE_PLAYER)) {
            logicalBoard[i] = CIRCLE_PLAYER;
        }
    }
    
} */

// Function to place a mark in the cell
function placeMark(cell, player) {
    cell.classList.add(player);
}
function endGame(draw) {
    if (draw) {
        winningMessageTextElement.innerText = 'Draw!'
    } else {
        winningMessageTextElement.innerText = `${player2 ? "Player O" : "Player X"} Wins!`
    }
    winningMessageElement.classList.add('show')
    
}
function showBoardHover(miniBoardNumber) {
    for (let i = 0; i < 9; i++) {
        const boardElement = document.getElementById(`tic-tac-toe-board-${i}`);
        if (boardElement) {
            if (i === miniBoardNumber) {
                boardElement.classList.add('active-subgrid');
            } else {
                boardElement.classList.remove('active-subgrid');
            }
        }
    }
}

// function showBoardHover(activeMiniBoard){
//     const boardElement = document.getElementById('tic-tac-toe-board-${activeMiniBoard}');
//     console.log("BOARD ELEMENT ", boardElement)
//     if (boardElement){
//         boardElement.classList.remove(X_PLAYER)
//         boardElement.classList.remove(CIRCLE_PLAYER)
//         if(player2){
//             boardElement.classList.add(CIRCLE_PLAYER)
//         } else {
//             boardElement.classList.add(X_PLAYER)
//         }
//     }
    
// }
function sendGameResults(result, miniBoardNumber){
    socket.send(JSON.stringify({type: 'result', data: {result, miniBoardNumber} }));
}

function updateCurrentPlayerDisplay() {
    const currentPlayerElement = document.getElementById('currentPlayer');
    if (currentPlayerElement) {
        currentPlayerElement.textContent = 'Current Player:' + currentPlayer;
    } else {
        console.error("Element with ID 'currentPlayer' not found");
    }
}
// Function to check for a win
function checkWin() {
    return WINNING_COMBINATIONS.some(combination => {
        return combination.every(index => {
            return cellElements[index].classList.contains(currentPlayer)
        })
    })
}

// Function to handle a win
function handleWin() {
    // Update win count based on the current player
    if (currentPlayer === X_PLAYER) {
        playerXWin++;
    } else {
        playerCircleWin++;
    }

    // Update the display
    updateWinCounts();

    // Display the winning message
    showWinningMessage(`Player ${currentPlayer.toUpperCase()} wins!`);
}

// Function to check for a draw
function isDraw() {
    return [...cellElements].every(cell => {
        return cell.classList.contains(X_PLAYER) || cell.classList.contains(CIRCLE_PLAYER   )
    })
}

// Function to handle a draw
function handleDraw() {
    // Display the draw message
    showWinningMessage('It\'s a draw!');
}

// Function to update win counts on the display
function updateWinCounts() {
    playerXWinsElement.textContent = playerXWin;
    playerOWinsElement.textContent = playerCircleWin;
}

// Function to switch to the other player
function switchPlayer() {
    console.log("CURRENT PLAYER ", player2)
    player2 = !player2;
    console.log("CURRENT PLAYER ", player2)

}

// Function to display the winning message
function showWinningMessage(message) {
    winningMessageTextElement.textContent = message;
    // Add logic to display the winning message element (you may want to add a class)
}
